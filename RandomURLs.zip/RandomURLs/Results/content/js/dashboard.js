/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.691304347826087, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "P2 - /outlet/901VC4EDGK/67755.html"], "isController": false}, {"data": [1.0, 500, 1500, "P2 - /outlet/600WTOB3696G/68357.html"], "isController": false}, {"data": [1.0, 500, 1500, "P1 - /outlet/890TBR72BG/67583.html"], "isController": false}, {"data": [1.0, 500, 1500, "P1 - /outlet/120VMASVP330/68299.html"], "isController": false}, {"data": [1.0, 500, 1500, "P2 - /outlet/415R3AFS/67917.html"], "isController": false}, {"data": [1.0, 500, 1500, "P2 - /outlet/890TBR72BG/67583.html"], "isController": false}, {"data": [0.5, 500, 1500, "P1 - /outlet/39021CET16C/68091.html"], "isController": false}, {"data": [1.0, 500, 1500, "P2 - /outlet/882G22010/67919.html"], "isController": false}, {"data": [0.425, 500, 1500, "Home Page 1 - outlet.html"], "isController": false}, {"data": [1.0, 500, 1500, "P2 - /outlet/945G4TP1T10A/68153.html"], "isController": false}, {"data": [1.0, 500, 1500, "P2 - /outlet/425LXER2/68375.html"], "isController": false}, {"data": [1.0, 500, 1500, "P2 - /outlet/200TBB4HC/68281.html"], "isController": false}, {"data": [1.0, 500, 1500, "P1 - /outlet/64959267/65157.html"], "isController": false}, {"data": [1.0, 500, 1500, "P2 - /outlet/1315001DA/67947.html"], "isController": false}, {"data": [1.0, 500, 1500, "P1 - /outlet/178HBB36HC/68467.html"], "isController": false}, {"data": [1.0, 500, 1500, "P2 - /outlet/901C24EO5AFD/68379.html"], "isController": false}, {"data": [0.425, 500, 1500, "Home Page 2 - outlet.html?page=2"], "isController": false}, {"data": [1.0, 500, 1500, "P1 - /outlet/425LXNH1/67847.html"], "isController": false}, {"data": [1.0, 500, 1500, "P2 - /outlet/415B700SF/68019.html"], "isController": false}, {"data": [1.0, 500, 1500, "P2 - /outlet/574E2SHCH/67787.html"], "isController": false}, {"data": [0.975, 500, 1500, "Home Page 2 - outlet.html?page=2-0"], "isController": false}, {"data": [1.0, 500, 1500, "P1 - /outlet/499UFP0200AA/68415.html"], "isController": false}, {"data": [0.475, 500, 1500, "Home Page 2 - outlet.html?page=2-1"], "isController": false}, {"data": [0.5, 500, 1500, "P2 - /outlet/177EF40E/68407.html"], "isController": false}, {"data": [1.0, 500, 1500, "P1 - /outlet/328HON716LCO/65959.html"], "isController": false}, {"data": [1.0, 500, 1500, "P1 - /outlet/177PPF40/67757.html"], "isController": false}, {"data": [0.75, 500, 1500, "P1 - /outlet/351GTUCPG48N/68001.html"], "isController": false}, {"data": [1.0, 500, 1500, "P1 - /outlet/185SM58HCW/68231.html"], "isController": false}, {"data": [1.0, 500, 1500, "P1 - /outlet/184T3300B/68431.html"], "isController": false}, {"data": [1.0, 500, 1500, "P1 - /outlet/2307UDIWCF/68289.html"], "isController": false}, {"data": [1.0, 500, 1500, "P1 - /outlet/415B700SF/68019.html"], "isController": false}, {"data": [1.0, 500, 1500, "P1 - /outlet/574E2SHCH/67787.html"], "isController": false}, {"data": [1.0, 500, 1500, "P1 - /outlet/517MCS72BK/68427.html"], "isController": false}, {"data": [1.0, 500, 1500, "P1 - /outlet/413GR5HL60YA/46921.html"], "isController": false}, {"data": [1.0, 500, 1500, "P2 - /outlet/425FD4503/67893.html"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 115, 0, 0.0, 760.7478260869566, 216, 1843, 809.0, 1391.0, 1576.6, 1832.7600000000002, 0.13671303814412644, 116.91009071690237, 0.022953069608929382], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["P2 - /outlet/901VC4EDGK/67755.html", 1, 0, 0.0, 349.0, 349, 349, 349.0, 349.0, 349.0, 349.0, 2.865329512893983, 682.379342765043, 0.43931321633237824], "isController": false}, {"data": ["P2 - /outlet/600WTOB3696G/68357.html", 1, 0, 0.0, 239.0, 239, 239, 239.0, 239.0, 239.0, 239.0, 4.184100418410042, 981.057139121339, 0.6496796548117155], "isController": false}, {"data": ["P1 - /outlet/890TBR72BG/67583.html", 1, 0, 0.0, 301.0, 301, 301, 301.0, 301.0, 301.0, 301.0, 3.3222591362126246, 1225.0798120847176, 0.5093698089700996], "isController": false}, {"data": ["P1 - /outlet/120VMASVP330/68299.html", 1, 0, 0.0, 487.0, 487, 487, 487.0, 487.0, 487.0, 487.0, 2.053388090349076, 640.951857674538, 0.3188366273100616], "isController": false}, {"data": ["P2 - /outlet/415R3AFS/67917.html", 1, 0, 0.0, 253.0, 253, 253, 253.0, 253.0, 253.0, 253.0, 3.952569169960474, 999.1160758399209, 0.5982892786561265], "isController": false}, {"data": ["P2 - /outlet/890TBR72BG/67583.html", 1, 0, 0.0, 295.0, 295, 295, 295.0, 295.0, 295.0, 295.0, 3.389830508474576, 1249.996689618644, 0.519729872881356], "isController": false}, {"data": ["P1 - /outlet/39021CET16C/68091.html", 1, 0, 0.0, 575.0, 575, 575, 575.0, 575.0, 575.0, 575.0, 1.7391304347826089, 558.1216032608696, 0.26834239130434784], "isController": false}, {"data": ["P2 - /outlet/882G22010/67919.html", 1, 0, 0.0, 461.0, 461, 461, 461.0, 461.0, 461.0, 461.0, 2.1691973969631237, 605.39037079718, 0.3304636659436008], "isController": false}, {"data": ["Home Page 1 - outlet.html", 20, 0, 0.0, 1050.75, 694, 1779, 917.0, 1673.4, 1774.05, 1779.0, 0.027715149239149865, 41.06345528489788, 0.003789180560040021], "isController": false}, {"data": ["P2 - /outlet/945G4TP1T10A/68153.html", 1, 0, 0.0, 338.0, 338, 338, 338.0, 338.0, 338.0, 338.0, 2.9585798816568047, 702.0906527366864, 0.45938886834319526], "isController": false}, {"data": ["P2 - /outlet/425LXER2/68375.html", 1, 0, 0.0, 353.0, 353, 353, 353.0, 353.0, 353.0, 353.0, 2.8328611898017, 779.7671742209632, 0.428802230878187], "isController": false}, {"data": ["P2 - /outlet/200TBB4HC/68281.html", 2, 0, 0.0, 433.0, 411, 455, 433.0, 455.0, 455.0, 455.0, 0.008344354835345017, 2.2575961660818664, 0.0012712103069470926], "isController": false}, {"data": ["P1 - /outlet/64959267/65157.html", 1, 0, 0.0, 442.0, 442, 442, 442.0, 442.0, 442.0, 442.0, 2.2624434389140275, 390.4217335972851, 0.34245970022624433], "isController": false}, {"data": ["P2 - /outlet/1315001DA/67947.html", 1, 0, 0.0, 394.0, 394, 394, 394.0, 394.0, 394.0, 394.0, 2.5380710659898473, 588.5003569162436, 0.3866592639593908], "isController": false}, {"data": ["P1 - /outlet/178HBB36HC/68467.html", 2, 0, 0.0, 370.0, 347, 393, 370.0, 393.0, 393.0, 393.0, 0.004168342687789048, 1.0664668130883876, 6.390916034989068E-4], "isController": false}, {"data": ["P2 - /outlet/901C24EO5AFD/68379.html", 1, 0, 0.0, 456.0, 456, 456, 456.0, 456.0, 456.0, 456.0, 2.1929824561403506, 571.3554516173245, 0.34051192434210525], "isController": false}, {"data": ["Home Page 2 - outlet.html?page=2", 20, 0, 0.0, 1340.55, 1093, 1843, 1311.5, 1573.3000000000002, 1829.7999999999997, 1843.0, 0.027693428211018386, 41.05679328231858, 0.007761732320861598], "isController": false}, {"data": ["P1 - /outlet/425LXNH1/67847.html", 1, 0, 0.0, 457.0, 457, 457, 457.0, 457.0, 457.0, 457.0, 2.1881838074398248, 504.61783711706784, 0.33121922866520787], "isController": false}, {"data": ["P2 - /outlet/415B700SF/68019.html", 1, 0, 0.0, 351.0, 351, 351, 351.0, 351.0, 351.0, 351.0, 2.849002849002849, 720.3859508547009, 0.4340277777777778], "isController": false}, {"data": ["P2 - /outlet/574E2SHCH/67787.html", 1, 0, 0.0, 283.0, 283, 283, 283.0, 283.0, 283.0, 283.0, 3.5335689045936394, 1022.4022747349824, 0.5383171378091873], "isController": false}, {"data": ["Home Page 2 - outlet.html?page=2-0", 20, 0, 0.0, 338.45, 248, 520, 334.5, 416.6, 514.8999999999999, 520.0, 0.027736365842665464, 0.02573198002981659, 0.003981685330929515], "isController": false}, {"data": ["P1 - /outlet/499UFP0200AA/68415.html", 1, 0, 0.0, 262.0, 262, 262, 262.0, 262.0, 262.0, 262.0, 3.8167938931297707, 924.1188573473282, 0.5926467080152672], "isController": false}, {"data": ["Home Page 2 - outlet.html?page=2-1", 20, 0, 0.0, 1001.55, 794, 1576, 961.5, 1244.9000000000003, 1560.1499999999996, 1576.0, 0.02770301810530748, 41.04530970372661, 0.0037875220065850075], "isController": false}, {"data": ["P2 - /outlet/177EF40E/68407.html", 1, 0, 0.0, 641.0, 641, 641, 641.0, 641.0, 641.0, 641.0, 1.5600624024960998, 407.82072689157565, 0.2361422581903276], "isController": false}, {"data": ["P1 - /outlet/328HON716LCO/65959.html", 1, 0, 0.0, 225.0, 225, 225, 225.0, 225.0, 225.0, 225.0, 4.444444444444445, 905.4904513888889, 0.6901041666666666], "isController": false}, {"data": ["P1 - /outlet/177PPF40/67757.html", 1, 0, 0.0, 270.0, 270, 270, 270.0, 270.0, 270.0, 270.0, 3.7037037037037037, 861.9502314814814, 0.5606192129629629], "isController": false}, {"data": ["P1 - /outlet/351GTUCPG48N/68001.html", 2, 0, 0.0, 534.5, 478, 591, 534.5, 591.0, 591.0, 591.0, 0.004159041756779238, 1.1986975700798537, 6.457887102811513E-4], "isController": false}, {"data": ["P1 - /outlet/185SM58HCW/68231.html", 1, 0, 0.0, 254.0, 254, 254, 254.0, 254.0, 254.0, 254.0, 3.937007874015748, 1019.3543922244095, 0.6036232775590551], "isController": false}, {"data": ["P1 - /outlet/184T3300B/68431.html", 1, 0, 0.0, 357.0, 357, 357, 357.0, 357.0, 357.0, 357.0, 2.8011204481792715, 1300.857843137255, 0.42673319327731096], "isController": false}, {"data": ["P1 - /outlet/2307UDIWCF/68289.html", 1, 0, 0.0, 247.0, 247, 247, 247.0, 247.0, 247.0, 247.0, 4.048582995951417, 1100.4831414473683, 0.6207300101214575], "isController": false}, {"data": ["P1 - /outlet/415B700SF/68019.html", 1, 0, 0.0, 265.0, 265, 265, 265.0, 265.0, 265.0, 265.0, 3.7735849056603774, 954.1715801886792, 0.5748820754716981], "isController": false}, {"data": ["P1 - /outlet/574E2SHCH/67787.html", 2, 0, 0.0, 275.5, 248, 303, 275.5, 303.0, 303.0, 303.0, 0.008322825765804006, 2.408088531718289, 0.001267930487759204], "isController": false}, {"data": ["P1 - /outlet/517MCS72BK/68427.html", 1, 0, 0.0, 216.0, 216, 216, 216.0, 216.0, 216.0, 216.0, 4.62962962962963, 902.6873553240741, 0.7098162615740741], "isController": false}, {"data": ["P1 - /outlet/413GR5HL60YA/46921.html", 1, 0, 0.0, 495.0, 495, 495, 495.0, 495.0, 495.0, 495.0, 2.0202020202020203, 564.1118213383838, 0.3136837121212121], "isController": false}, {"data": ["P2 - /outlet/425FD4503/67893.html", 1, 0, 0.0, 368.0, 368, 368, 368.0, 368.0, 368.0, 368.0, 2.717391304347826, 577.0051375679348, 0.41397758152173914], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 115, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
